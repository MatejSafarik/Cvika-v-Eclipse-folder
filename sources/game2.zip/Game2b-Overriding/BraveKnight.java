
public class BraveKnight extends Knight {
	void attack(Ogre obor) {
		obor.energy = 0;
	}
}
